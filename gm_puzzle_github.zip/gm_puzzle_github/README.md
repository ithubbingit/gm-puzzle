# GM Puzzle — GitHub Pages

## Publish
1. Sign in to GitHub and create a new **public** repository (for example `gm-puzzle`).
2. Upload `index.html` from this folder to the repository's top level and commit it to the `main` branch.
3. Open the repository's **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then click **Save**.
6. Wait for GitHub Pages to publish. The site address will look like `https://YOUR-USERNAME.github.io/gm-puzzle/`.
7. Add that URL to your Google Site as a button/link and set it to open in a new tab.

## Important: Supabase access
The game still uses its existing Supabase backend. GitHub Pages hosting does not remove browser CORS restrictions. The Supabase project owner must allow the exact published GitHub Pages origin (for example `https://YOUR-USERNAME.github.io`) in the `auth-username` Edge Function's CORS handling, including `OPTIONS` preflight requests. If they cannot change the Supabase function, login may continue to fail.

Keep the existing authentication code intact. Do not put Supabase service-role keys or other secrets in this public repository.
